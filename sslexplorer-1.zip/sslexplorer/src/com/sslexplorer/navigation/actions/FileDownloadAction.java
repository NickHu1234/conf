
				/*
 *  SSL-Explorer
 *
 *  Copyright (C) 2003-2006 3SP LTD. All Rights Reserved
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2 of
 *  the License, or (at your option) any later version.
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public
 *  License along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
			
package com.sslexplorer.navigation.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.sslexplorer.core.CoreUtil;
import com.sslexplorer.core.DownloadContent;
import com.sslexplorer.core.FileDownloadPageInterceptListener;
import com.sslexplorer.core.actions.DefaultAction;
import com.sslexplorer.security.SessionInfo;

/**
 * Action for doing the actual download.
 */
public class FileDownloadAction extends DefaultAction {

    /* (non-Javadoc)
     * @see com.sslexplorer.core.actions.DefaultAction#execute(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
                    throws Exception {
        String id = request.getParameter("id");
        if (id == null) {
            return mapping.findForward("failed");
        }
        FileDownloadPageInterceptListener l = (FileDownloadPageInterceptListener) CoreUtil.getPageInterceptListenerById(request
                        .getSession(),FileDownloadPageInterceptListener.INTERCEPT_ID);
        DownloadContent download = l == null ? null : l.getDownload(Integer.parseInt(id));
        if (l == null || download == null ) {
            return mapping.findForward("failed");
        }

        response.setContentType(download.getMimeType() == null ? "application/octet-stream" : download.getMimeType());
        response.setHeader("Content-Disposition", "attachment; filename=\"" + download.getFileName() + "\"");
        download.sendDownload(response, request);

        return null;

    }

    /* (non-Javadoc)
     * @see com.sslexplorer.core.actions.CoreAction#getNavigationContext(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public int getNavigationContext(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        return SessionInfo.ALL_CONTEXTS;
    }

}