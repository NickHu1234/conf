package com.sslexplorer.boot;

public class Branding {
    public final static String PRODUCT_NAME = "SSL-Explorer";
    public final static String SERVICE_NAME = "sslexplorer";
    public final static String VENDOR_URL = "http://3sp.com";
}
