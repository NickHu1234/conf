package com.sslexplorer.boot;

public class ContextKey extends AbstractPropertyKey {

    public ContextKey(String name) {
        super(name, ContextConfig.NAME);
    }

}
