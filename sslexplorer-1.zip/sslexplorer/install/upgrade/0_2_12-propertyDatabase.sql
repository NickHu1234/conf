UPDATE EXPLORER_PROPERTIES SET VALUE = 'list' WHERE KEY_1 = 'ui.defaultManagementConsoleViewType';
