package com.sslexplorer.agent.client;

public class HOSTS {
	
	private static HOSTS instance;
	
	
}
