package com.sslexplorer.agent.client;

/**
 * Interface for callbacks when popups are clicked 
 */
public interface ActionCallback {
	public void actionPerformed();
}