package com.maverick.multiplex;

public interface MultiplexedConnectionListener {
	public void onConnectionOpen();	
    public void onConnectionClose();	
}
