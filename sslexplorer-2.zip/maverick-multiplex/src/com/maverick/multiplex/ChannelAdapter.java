package com.maverick.multiplex;

public class ChannelAdapter implements ChannelListener {

	public void onChannelClose(Channel channel) {

	}

	public void onChannelData(Channel channel, byte[] buf, int off, int len) {

	}

	public void onChannelOpen(Channel channel) {

	}

}
