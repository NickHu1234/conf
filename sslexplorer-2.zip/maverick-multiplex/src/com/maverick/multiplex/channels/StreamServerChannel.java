package com.maverick.multiplex.channels;

public interface StreamServerChannel {

    boolean isInitiator();

    String getId();

}
